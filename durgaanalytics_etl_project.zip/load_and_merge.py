import pandas as pd
import json

# Step 1: Load campaign.csv with safe encoding
df_campaign = pd.read_csv("campaign.csv", encoding="ISO-8859-1")
print("✅ Loaded campaign.csv")

# 🔧 Fix BOM in column name
df_campaign.rename(columns={'ï»¿tenant_id': 'tenant_id'}, inplace=True)

# Step 2: Load targets.xlsx
df_targets = pd.read_excel("targets.xlsx")
print("✅ Loaded targets.xlsx")

# Step 3: Load customers.json
with open("customers.json", "r") as f:
    customer_data = json.load(f)

df_customers = pd.DataFrame(customer_data)
print("✅ Loaded customers.json")

# Step 4: Clean column names
df_campaign.columns = df_campaign.columns.str.strip().str.lower()
df_customers.columns = df_customers.columns.str.strip().str.lower()

# ✅ Debug: Print column names before merging
print("📋 campaign.csv columns:", df_campaign.columns.tolist())
print("📋 customers.json columns:", df_customers.columns.tolist())

# Step 5: Merge campaign with customer metadata (on tenant_id)
df_merged = df_campaign.merge(df_customers, on="tenant_id", how="left")

# Step 6: Add calculated fields
df_merged['ctr'] = df_merged['clicks'] / df_merged['leads']
df_merged['roi'] = (df_merged['conversions'] * 100) / df_merged['spend']
df_merged['date'] = pd.to_datetime(df_merged['date'])

# Step 7: View final merged dataset
print("\n📊 Final Combined Data:")
print(df_merged)

# Step 8: Save to new CSV
df_merged.to_csv("final_merged_data.csv", index=False)
print("\n✅ Saved final_merged_data.csv")
